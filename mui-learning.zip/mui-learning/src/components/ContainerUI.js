import React from "react";
import { Container } from "@mui/material"

const ContainerUI = () => {
    return <>
    <Container sx={{background:"red",textAlign:"center"}}maxWidth="xs">
        XS Container
    </Container>
    <br/>
    <Container sx={{background:"red",textAlign:"center"}}maxWidth="sm">
        SM Container
    </Container>
    <br/>
    <Container sx={{background:"red",textAlign:"center"}}maxWidth="md">
        MD Container
    </Container>
    <br/>
    <Container sx={{background:"red",textAlign:"center"}}maxWidth="lg">
        LG Container
    </Container>
    <br/>
    <Container sx={{background:"red",textAlign:"center"}}maxWidth="xl">
        XL Container
    </Container>
    <br/>
    </>
}

export default ContainerUI;