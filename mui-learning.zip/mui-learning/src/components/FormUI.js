import React, { useState } from "react";
import { Button, TextField, FormGroup, FormControlLabel, Checkbox, FormControl, InputLabel, Select, MenuItem, RadioGroup, Radio, FormLabel } from "@mui/material"

const FormUI = () => {
    const [inputs, setInputs] = useState({
        name: "",
        email: "",
        password: "",
        subscribe: false,
        age: 0,
        gender: ''
    });
    const handleChange = (e) => {
        setInputs((prevInputs)=> ({
            ...prevInputs,
            [e.target.name]: e.target.value
        }))
    }
    const handleSubmit = (e) => {
        e.preventDefault();
        console.log(inputs)
    }
    return <>
    <form onSubmit={handleSubmit} style={{display:"flex", flexDirection:"column", width:'50%'}}>
    <TextField name="name" value={inputs.name} onChange={handleChange} type="text" placeholder="Name" variant="filled" sx={{margin: 3}}/>
    <TextField name="email" value={inputs.email} onChange={handleChange} type="email" placeholder="Email" variant="outlined" sx={{margin: 3}}/>
    <TextField name="password" value={inputs.password} onChange={handleChange} type="password" placeholder="Password" variant="outlined" sx={{margin: 3}}/>
    <FormGroup>
        <FormControlLabel onChange={(e) => setInputs((prev)=>({
            ...prev,
            subscribe: !inputs.subscribe
        }))} control={<Checkbox />} label="Subscribe to this form" />
    </FormGroup>
    <FormControl fullWidth>
  <InputLabel>Age</InputLabel>
  <Select
    name='age'
    value={inputs.age}
    label="Age"
    onChange={handleChange}
  >
    <MenuItem value={10}>Ten</MenuItem>
    <MenuItem value={20}>Twenty</MenuItem>
    <MenuItem value={30}>Thirty</MenuItem>
  </Select>
</FormControl>

<FormControl>
      <FormLabel>Gender</FormLabel>
      <RadioGroup
        onChange={handleChange}
        name="gender"
      >
        <FormControlLabel value="female" control={<Radio />} label="Female" />
        <FormControlLabel value="male" control={<Radio />} label="Male" />
        <FormControlLabel value="other" control={<Radio />} label="Other" />
      </RadioGroup>
    </FormControl>
    <Button type="submit" variant="contained">Submit</Button>
    </form>
    </>
}

export default FormUI;