import React, { useState } from "react";
import { Alert } from "@mui/material";

const alert = ["error","warning","info","success"]

const AlertUI = () => {
    const [alertClose, setAlertClose] = useState({
        error: true,
        warning: true,
        info: true,
        success: true
    });

    const handleClose = (e) => {
        setAlertClose((prevInputs)=> ({
            ...prevInputs,
            [e]: !alertClose
        }))
    }
    return <>
   {
    alert.map((ele) => (
        alertClose[ele] && <Alert variant="outlined" sx={{margin:3}} onClose={()=> handleClose(ele)} severity={ele}>This is an {ele} alert — check it out!</Alert>
    ))
   }
    </>
}

export default AlertUI;