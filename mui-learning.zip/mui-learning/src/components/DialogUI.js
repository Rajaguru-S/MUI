import React, { useState } from "react";
import { Button, Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle } from "@mui/material"

const DialogUI = () => {
    const [open, setOpen] = useState(false);
    return <>
    <Button sx={{ margin:3}} onClick={()=>setOpen(true)} variant="contained">Click here to open Dialog</Button>
    <Dialog open={open} onClose={()=>setOpen(false)}>
        <DialogTitle>Dialog Title</DialogTitle>
        <DialogContent>
            <DialogContentText>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</DialogContentText>
        </DialogContent>
        <DialogActions>
            <Button onClick={()=>setOpen(false)}>Close</Button>
            <Button onClick={()=>setOpen(false)}>Agree</Button>
        </DialogActions>
    </Dialog>
    </>
}

export default DialogUI;