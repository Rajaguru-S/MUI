import React from "react";
import { Link } from "@mui/material"

const LinkUI = () => {
    return <>
    <Link variant="h6" color="inherit" underline="hover" href="https://www.google.com" target="_blank" > Click to visit Google</Link>
    </>
}

export default LinkUI;