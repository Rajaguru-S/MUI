import React from "react";
import { Checkbox, ThemeProvider, Typography, createTheme, useTheme } from "@mui/material"

const ThemeUI = () => {
    const theme = useTheme();
    const outerTheme = createTheme({
        palette: {
          primary: {
            main: "#FF0000",
          },
        },
      });
      
      const innerTheme = createTheme({
        palette: {
          primary: {
            main: "#00FF00",
          },
        },
      });
    console.log(theme);
    return <>
        <ThemeProvider theme={outerTheme}>
      <Checkbox defaultChecked />
      <Typography color="primary">Primary</Typography>
      <ThemeProvider theme={innerTheme}>
        <Checkbox defaultChecked />
      <Typography color="primary">Secondary</Typography>
      </ThemeProvider>
    </ThemeProvider>
    </>
}

export default ThemeUI;