import React, { useState } from "react";
import { Alert, Snackbar } from "@mui/material";


const SnackbarUI = () => {
    const [open, setOpen] = useState(true)
  
    return <>
       <Snackbar
            open={open}
            onClose={()=> setOpen(false)}
            autoHideDuration={5000}
            message="It will hide after 5 seconds"
            />

<Snackbar open={open} autoHideDuration={6000}  onClose={()=> setOpen(false)}>
  <Alert  onClose={()=> setOpen(false)} severity="success" sx={{ width: '100%' }}>
  Snackbar Alert Notification It will hide after 5 seconds
  </Alert>
</Snackbar>
    </>
}

export default SnackbarUI;