import React, { useState } from "react";
import { Rating, Typography } from "@mui/material"

const RatingUI = () => {
    const [value, setValue] = useState();
    return <>
    <Rating precision={0.1} value={value} onChange={(e,val)=>setValue(val)} />
    <Typography>Rating {value!==undefined ? value: 0}</Typography>
    </>
}

export default RatingUI;