import React, { useState } from "react";
import { TextField, Typography } from "@mui/material"

const TextfieldUI = () => {
    const [name, setName] = useState("Type your Name");
    return <>
    <TextField onChange={(e)=> setName(e.target.value)} type="text" placeholder="Name" variant="filled" sx={{margin: 3}}/>
    <TextField type="email" placeholder="Email" variant="outlined" sx={{margin: 3}}/>
    <TextField type="password" placeholder="Password" variant="outlined" sx={{margin: 3}}/>
    <Typography>{name}</Typography>
    </>
}

export default TextfieldUI;