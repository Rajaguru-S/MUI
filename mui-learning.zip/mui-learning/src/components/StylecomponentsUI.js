import React from "react";
import { Typography, styled } from "@mui/material";

const CustomizedTypo = styled(Typography)`
  color: #20b2aa;

  :hover {
    color: #2e8b57;
  }
`;

const StylecomponentsUI = () => {
    return <>
    <CustomizedTypo variant="h1">Customized Typo</CustomizedTypo>
    </>
}

export default StylecomponentsUI;