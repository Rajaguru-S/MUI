import React from "react";
import { Collapse, List, ListItemButton, ListItemIcon, ListItemText, ListSubheader } from "@mui/material"

const ListUI = () => {
    const [open, setOpen] = React.useState(false);

    const handleClick = () => {
      setOpen(!open);
    };
    const lists = ['One', 'Two', 'Three', 'Four']
    return <>
    <List sx={{maxWidth:"300px", background: "grey"}} subheader={
        <ListSubheader component="div" id="nested-list-subheader">
          Nested List Items
        </ListSubheader>
      }>

        {
            lists.map((lis) => (
                <ListItemButton divider >
                   
                    <ListItemText primary={lis} />
                </ListItemButton>
            ))
        }
 <ListItemButton divider  onClick={handleClick}>
                   
                    <ListItemText primary="Five" />
                    <ListItemIcon>{">"}</ListItemIcon>
                </ListItemButton>
<Collapse in={open} timeout="auto" unmountOnExit>
        <List component="div" disablePadding>
          <ListItemButton sx={{ pl: 4 }}>
            <ListItemText primary="Starred" />
          </ListItemButton>
        </List>
      </Collapse>

    </List>
  
    </>
}

export default ListUI;