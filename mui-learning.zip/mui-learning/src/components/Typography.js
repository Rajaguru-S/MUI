import React from "react";
import { Typography } from "@mui/material"

const Typography1 = () => {
    return <>
    <Typography variant="h2" sx={{marginTop:10}}>Hi Kingguru!!!</Typography>
    </>
}

export default Typography1;