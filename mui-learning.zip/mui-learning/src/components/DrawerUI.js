import React, { useState } from "react";
import { Button, Drawer, List, ListItem, ListItemButton, ListItemText } from "@mui/material";
const list = ['All mail', 'Trash', 'Spam'];

const DrawerUI = () => {
    const [open, setOpen]= useState(false);
    return <>
    <Button onClick={()=> setOpen(true)}>Click to Open Drawer</Button>
    <Drawer anchor="left" open={open} onClose={()=> setOpen(false)}>
    <List>
        {list.map((text, index) => (
          <ListItem key={text}>
            <ListItemButton onClick={()=> setOpen(false)}>
              <ListItemText primary={text} />
            </ListItemButton>
          </ListItem>
        ))}
      </List>
    </Drawer>
    </>
}

export default DrawerUI;