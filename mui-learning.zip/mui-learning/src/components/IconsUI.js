import React from "react";
import AccountCircleIcon from '@mui/icons-material/AccountCircle';

const IconsUI = () => {
    return <>
    
    <AccountCircleIcon sx={{marginRight:1}}/>

    </>
}

export default IconsUI;