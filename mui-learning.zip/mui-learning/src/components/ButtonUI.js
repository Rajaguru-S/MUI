import React from "react";
import { Button } from "@mui/material"

const ButtonUI = () => {
    return <>
    <Button onClick={()=>alert('Button 1')} sx={{margin:3}} size="large" variant="contained">First</Button>
    <Button onClick={()=>alert('Button 2')} sx={{margin:3}} size="medium" variant="outlined">Second</Button>
    <Button onClick={()=>alert('Button 3')} sx={{margin:3}} size="small" variant="link">Third</Button>
    </>
}

export default ButtonUI;