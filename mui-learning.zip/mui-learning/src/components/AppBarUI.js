import React, { useState } from "react";
import { AppBar, Button, Tab, Tabs, Toolbar, Typography } from "@mui/material"
import LinkUI from "./LinkUI";
import IconsUI from "./IconsUI";

const AppBarUI = () => {
    const [val,setVal] = useState(0);
    return <>
    <AppBar>
        <Toolbar>
            <Typography>Logo</Typography>
            <Tabs value={val} onChange={(e,v)=>setVal(v)} textColor="inherit" indicatorColor="secondary">
                <Tab label="First"/>
                <Tab label="Second"/>
                <Tab label="Third"/>

            </Tabs>
            <LinkUI />
            <Button variant="contained" color="warning" sx={{marginLeft:'auto'}}> <IconsUI/> Login</Button>
        </Toolbar>
    </AppBar>
    </>
}

export default AppBarUI;