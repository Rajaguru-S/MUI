import React from "react";
import { CircularProgress, LinearProgress } from "@mui/material"

const ProgressbarUI = () => {
    return <>
    
        <CircularProgress sx={{margin:3}}/>
        <LinearProgress sx={{margin:3}} />
        
        <CircularProgress sx={{margin:3}} variant="determinate" value={25}/>
        <LinearProgress sx={{margin:3}} variant="determinate" value={25}/>
    </>
}

export default ProgressbarUI;