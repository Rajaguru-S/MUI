import './App.css';
import Typography1 from './components/Typography';
import ButtonUI from './components/ButtonUI';
import TextfieldUI  from './components/TextfieldUI';
import FormUI from './components/FormUI';
import AppBarUI from './components/AppBarUI';
import CardUI from './components/CardUI';
import DialogUI from './components/DialogUI';
import ModalUI from './components/ModalUI';
import ContainerUI from './components/ContainerUI';
import ListUI from './components/ListUI';
import AccordionUI from './components/AccordionUI';
import AutocompleteUI from './components/AutocompleteUI';
import DrawerUI from './components/DrawerUI';
import AlertUI from './components/AlertUI';
import SnackbarUI from './components/SnackbarUI';
import ProgressbarUI from './components/ProgressbarUI';
import RatingUI from './components/RatingUI';
import ImagelistUI from './components/ImagelistUI';
import DatagridUI from './components/DatagridUI';
import ThemeUI from './components/ThemeUI';
import StylecomponentsUI from './components/StylecomponentsUI';
import GridUI from './components/GridUI';

function App() {
  return (
    <div>
      <AppBarUI />
      <Typography1 />
      <ProgressbarUI />
      <RatingUI />
      <StylecomponentsUI />
      <AlertUI />
      <GridUI />
      <ThemeUI />
      <ImagelistUI />
      <DatagridUI />
      <SnackbarUI />
      <AccordionUI />
      <AutocompleteUI />
      <DrawerUI />
      <DialogUI />
      <ModalUI />
      <ListUI />
      <ContainerUI />
      <CardUI />
      <ButtonUI />
      <TextfieldUI />
      <FormUI />
    </div>
  );
}

export default App;
